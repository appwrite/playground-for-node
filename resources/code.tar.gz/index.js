module.exports = async (req, res) => {
    res.json({
        message: "Hello Open Runtimes 👋"
    });
}
