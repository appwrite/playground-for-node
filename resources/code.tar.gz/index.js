module.exports = async ({req, res}) => {
    return res.json({
        message: "Hello Open Runtimes 👋"
    });
}
